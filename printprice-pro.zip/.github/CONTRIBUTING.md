# Contributing to PrintPrice Pro

We welcome contributions to PrintPrice Pro! Here's how you can help:

## 🛠️ How to Contribute

1. Fork the repository
2. Create a new branch for your fix or feature
3. Make your changes
4. Commit and push to your branch
5. Open a pull request

## 📋 Guidelines

- Follow WordPress PHP coding standards
- Use clear and descriptive commit messages
- Document your code and update the changelog if needed
- Keep translations in English (source)

## 🧪 Testing

Please test your changes on a local WordPress environment before submitting a PR.

Thanks for helping improve PrintPrice Pro!
