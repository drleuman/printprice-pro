# 📦 Pull Request

## ✅ Summary

- Short description of the changes made.
- Reference related issues if any.

## 🔍 Changes

- What was added/changed/removed?

## 🧪 Testing

- Describe how this was tested and what steps were taken.

## 📝 Checklist

- [ ] Code follows WordPress coding standards
- [ ] Changes documented in `CHANGELOG.md`
- [ ] Translatable strings updated if needed
- [ ] Tests (if applicable) added/passed
