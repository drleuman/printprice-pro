=== PrintPrice Pro ===
Contributors: printpricepro
Tags: print, ai, woo, cart, pdf, order, imprenta
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Unified plugin for managing AI-based print orders, WooCommerce integration, PDF generation and selection of printing houses.

== Description ==

This plugin handles the entire order lifecycle from chatbot to checkout:
* Receives AI-generated print specs.
* Creates a custom print order.
* Allows print house selection.
* Adds WooCommerce cart item.
* Generates PDF summary.
* Syncs ACF fields and WooCommerce order data.

== Author ==
Developed by Manuel Enrique Morales for [PrintPrice.pro](https://printprice.pro)

== Changelog ==
= 1.0.0 =
* Initial unified release.
